// This file is a PLACEHOLDER.
//
// Run the following command from the project root to generate the real
// version of this file, wired to your own Firebase project:
//
//   dart pub global activate flutterfire_cli
//   flutterfire configure --project=your-firebase-project-id
//
// That command overwrites this file with real API keys/App IDs for
// Android, iOS, and Web, and registers the apps in your Firebase project
// automatically. Do NOT hand-edit the generated file — always regenerate it
// via the CLI if you add/remove a platform.
//
// See README.md → "Firebase Setup" for the full walkthrough.

import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart' show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      throw UnsupportedError(
        'DefaultFirebaseOptions have not been configured for web - '
        'run `flutterfire configure` to generate this file.',
      );
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
      case TargetPlatform.iOS:
      case TargetPlatform.macOS:
      case TargetPlatform.windows:
      case TargetPlatform.linux:
        throw UnsupportedError(
          'DefaultFirebaseOptions have not been configured for this platform - '
          'run `flutterfire configure` to generate this file with your real '
          'Firebase project credentials.',
        );
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }
}
