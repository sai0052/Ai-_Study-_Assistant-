import 'package:dio/dio.dart';
import '../../../../config/env/env.dart';
import '../../../../core/error/exceptions.dart';
import '../../../../core/network/api_client.dart';

/// Talks directly to the Google Gemini REST API.
///
/// SECURITY NOTE (explained in README too): shipping the Gemini key inside
/// the compiled app is fine for a portfolio/demo build, but for real
/// production you should replace this class's `baseUrl`/headers with a call
/// to your own Firebase Cloud Function that holds the key server-side, so
/// the key never appears in the client binary. Because this class sits
/// behind the AiRepository interface, that swap only touches this one file.
abstract class AiRemoteDataSource {
  Future<String> generateText(String prompt);
}

class GeminiRemoteDataSource implements AiRemoteDataSource {
  final ApiClient apiClient;

  GeminiRemoteDataSource({ApiClient? client})
      : apiClient = client ??
            ApiClient(baseUrl: 'https://generativelanguage.googleapis.com/v1beta/models');

  @override
  Future<String> generateText(String prompt) async {
    try {
      final response = await apiClient.post(
        '/gemini-1.5-flash:generateContent?key=${Env.geminiApiKey}',
        data: {
          'contents': [
            {
              'parts': [
                {'text': prompt}
              ]
            }
          ],
          'generationConfig': {
            'temperature': 0.7,
            'maxOutputTokens': 1024,
          },
        },
      );

      final candidates = response.data['candidates'] as List?;
      if (candidates == null || candidates.isEmpty) {
        throw AiException('The AI returned no response. Try rephrasing your question.');
      }

      final text = candidates[0]['content']['parts'][0]['text'] as String?;
      if (text == null || text.trim().isEmpty) {
        throw AiException('The AI returned an empty response.');
      }
      return text.trim();
    } on DioException catch (e) {
      final message = e.response?.data?['error']?['message'] ?? e.message;
      throw AiException('AI request failed: $message');
    }
  }
}
