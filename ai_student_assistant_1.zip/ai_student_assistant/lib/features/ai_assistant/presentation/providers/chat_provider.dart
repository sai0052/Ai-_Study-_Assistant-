import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../../data/datasources/ai_remote_datasource.dart';
import '../../data/repositories/ai_repository_impl.dart';
import '../../domain/entities/chat_message_entity.dart';
import '../../domain/repositories/ai_repository.dart';
import '../../domain/usecases/ask_question_usecase.dart';
import '../../domain/usecases/generate_quiz_usecase.dart';
import '../../domain/usecases/summarize_text_usecase.dart';

final aiRemoteDataSourceProvider = Provider<AiRemoteDataSource>((ref) => GeminiRemoteDataSource());
final aiRepositoryProvider = Provider<AiRepository>((ref) => AiRepositoryImpl(ref.watch(aiRemoteDataSourceProvider)));

final askQuestionUsecaseProvider = Provider((ref) => AskQuestionUsecase(ref.watch(aiRepositoryProvider)));
final summarizeTextUsecaseProvider = Provider((ref) => SummarizeTextUsecase(ref.watch(aiRepositoryProvider)));
final generateQuizUsecaseProvider = Provider((ref) => GenerateQuizUsecase(ref.watch(aiRepositoryProvider)));

/// Holds the in-memory chat transcript + loading state for the AI Chat screen.
/// (For persistence across app restarts, wire this to Firestore the same
/// way the Notes/Tasks features do — see notes_provider.dart for the pattern.)
class ChatController extends StateNotifier<List<ChatMessageEntity>> {
  final Ref ref;
  final _uuid = const Uuid();
  bool isLoading = false;

  ChatController(this.ref) : super([]);

  Future<void> sendMessage(String text) async {
    if (text.trim().isEmpty) return;

    final userMessage = ChatMessageEntity(
      id: _uuid.v4(),
      text: text.trim(),
      sender: MessageSender.user,
      timestamp: DateTime.now(),
    );
    state = [...state, userMessage];

    isLoading = true;
    state = [...state]; // trigger rebuild for typing indicator

    final result = await ref.read(askQuestionUsecaseProvider).call(text.trim());
    isLoading = false;

    result.fold(
      (failure) {
        state = [
          ...state,
          ChatMessageEntity(
            id: _uuid.v4(),
            text: "Sorry, I couldn't process that: ${failure.message}",
            sender: MessageSender.ai,
            timestamp: DateTime.now(),
          ),
        ];
      },
      (answer) {
        state = [
          ...state,
          ChatMessageEntity(id: _uuid.v4(), text: answer, sender: MessageSender.ai, timestamp: DateTime.now()),
        ];
      },
    );
  }

  void clearChat() => state = [];
}

final chatControllerProvider = StateNotifierProvider<ChatController, List<ChatMessageEntity>>((ref) {
  return ChatController(ref);
});
