import 'package:dartz/dartz.dart';
import '../../../../core/error/failures.dart';

/// Contract for all AI-powered operations. The concrete implementation can
/// call Gemini, OpenAI, or a proxy Cloud Function — the rest of the app
/// doesn't care which, as long as it fulfills this contract.
abstract class AiRepository {
  Future<Either<Failure, String>> askQuestion(String question);
  Future<Either<Failure, String>> summarizeText(String text);
  Future<Either<Failure, List<String>>> generateQuiz(String topic, {int questionCount = 5});
  Future<Either<Failure, String>> studyRecommendation({required List<String> weakTopics});
}
