import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../ai_assistant/presentation/providers/chat_provider.dart';
import '../../../tasks/presentation/providers/tasks_provider.dart';

/// Fetches a fresh AI study recommendation whenever this provider is
/// watched. FutureProvider auto-caches the result until the widget/provider
/// is disposed or invalidated (e.g. pull-to-refresh on the dashboard).
final aiSuggestionProvider = FutureProvider<String>((ref) async {
  final upcomingTasks = ref.watch(upcomingDeadlinesProvider);
  final weakTopics = upcomingTasks.map((t) => t.title).toList();

  final aiRepository = ref.watch(aiRepositoryProvider);
  final result = await aiRepository.studyRecommendation(weakTopics: weakTopics);

  return result.fold(
    (failure) => 'Stay consistent — even 25 focused minutes today keeps you on track!',
    (suggestion) => suggestion,
  );
});
