import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../../../core/constants/app_sizes.dart';
import '../../../../core/widgets/custom_button.dart';
import '../providers/auth_provider.dart';

/// The 5th bottom-nav tab: shows the signed-in student's profile details
/// and settings, plus dark/light mode toggle and sign-out.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authStateChangesProvider).value;
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(AppSizes.lg),
        children: [
          Center(
            child: CircleAvatar(
              radius: 40,
              backgroundColor: theme.colorScheme.primary.withValues(alpha: 0.12),
              backgroundImage: user?.photoUrl != null ? NetworkImage(user!.photoUrl!) : null,
              child: user?.photoUrl == null
                  ? Icon(Icons.person, size: 40, color: theme.colorScheme.primary)
                  : null,
            ),
          ),
          const SizedBox(height: AppSizes.md),
          Center(child: Text(user?.name ?? 'Student', style: theme.textTheme.titleLarge)),
          Center(child: Text(user?.email ?? '', style: theme.textTheme.bodyMedium)),
          const SizedBox(height: AppSizes.xl),

          Card(
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.apartment_outlined),
                  title: const Text('College'),
                  subtitle: Text(user?.collegeName ?? 'Not set'),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.menu_book_outlined),
                  title: const Text('Course'),
                  subtitle: Text(user?.course ?? 'Not set'),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppSizes.xl),

          CustomButton(
            label: 'Sign Out',
            outlined: true,
            onPressed: () => ref.read(authControllerProvider.notifier).signOut(),
          ),
        ],
      ),
    );
  }
}
